package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Certificate;
import com.example.demo.service.CertificateService;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
public class CertificateController {
@Autowired
CertificateService cs1;
@PostMapping("/certificates")
public  Certificate saveCertificate(@RequestBody  Certificate certificate) {
    //TODO: process POST request
    
    return cs1.saveCertificate(certificate);
}

@GetMapping("/certificates")
public List<Certificate> fetchCertificateList() {
   
    return cs1.fetchCertificateList();
}

@GetMapping("/certificates/{id}")
public Certificate fetchCertificateById(@PathVariable("id") Long id) {
    return cs1.fetchCertificateById(id);
}

@DeleteMapping("/certificates/{id}")
public String deleteCertificateById(@PathVariable("id") Long id) {
    cs1.deleteCertificateById(id);
    return "row deleted Successfully!!";
}

@PutMapping("/certificates/{id}")
public Certificate updateCertificate(@PathVariable("id") Long id,
                                   @RequestBody Certificate certificate) {
    return cs1.updateStudent(id,certificate);
}


}
