package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Certificate;

@Service
public interface CertificateService {

	Certificate saveCertificate(Certificate certificate);

	List<Certificate> fetchCertificateList();

	Certificate fetchCertificateById(Long id);
	
	void deleteCertificateById(Long id);

	Certificate updateStudent(Long id, Certificate certificate);

	
}
