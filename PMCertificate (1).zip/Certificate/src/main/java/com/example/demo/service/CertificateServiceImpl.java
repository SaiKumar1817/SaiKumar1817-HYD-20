package com.example.demo.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Certificate;
import com.example.demo.repository.CertificateRepository;

@Service
public class CertificateServiceImpl implements CertificateService {
@Autowired
 CertificateRepository cr1;

@Override
public Certificate saveCertificate(Certificate certificate) {
	// TODO Auto-generated method stub
	return cr1.save(certificate);
}

@Override
public List<Certificate> fetchCertificateList() {
	// TODO Auto-generated method stub
	return cr1.findAll();
}

@Override
public Certificate fetchCertificateById(Long id) {
	// TODO Auto-generated method stub
	return cr1.findById(id).get();
}

@Override
public void deleteCertificateById(Long id) {
	// TODO Auto-generated method stub
	cr1.deleteById(id);
}

@Override
public Certificate updateStudent(Long id, Certificate certificate) {
	
	Certificate cerDB = cr1.findById(id).get();
	
	 if(Objects.nonNull(certificate.getYear()) &&
              !"".equalsIgnoreCase(certificate.getYear())) {
          cerDB.setYear(certificate.getYear());
      }
    
      if(Objects.nonNull(certificate.getCollege()) &&
              !"".equalsIgnoreCase(certificate.getCollege())) {
          cerDB.setCollege(certificate.getCollege());
      }
      
	return cr1.save(cerDB);
}


 
}
